<?php
/**
 *  Leo Prestashop SliderShow for Prestashop 1.6.x
 *
 * @package   leosliderlayer
 * @version   3.0
 * @author    http://www.leotheme.com
 * @copyright Copyright (C) October 2013 LeoThemes.com <@emai:leotheme@gmail.com>
 *               <info@leotheme.com>.All rights reserved.
 * @license   GNU General Public License version 2
 */

global $_MODULE;
$_MODULE = array();

$_MODULE['<{homeslider}prestashop>homeslider_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_MODULE['<{homeslider}prestashop>homeslider_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{homeslider}prestashop>homeslider_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{homeslider}prestashop>homeslider_7dce122004969d56ae2e0245cb754d35'] = 'Edit';
$_MODULE['<{homeslider}prestashop>homeslider_f2a6c498fb90ee345d997f888fce3b18'] = 'Delete';
$_MODULE['<{homeslider}prestashop>homeslider_51ec9bf4aaeab1b25bb57f9f8d4de557'] = 'Title';
$_MODULE['<{homeslider}prestashop>homeslider_3b3d06023f6353f8fd05f859b298573e'] = 'URL';
$_MODULE['<{homeslider}prestashop>homeslider_8046c95f98fc714db47978092bb24264'] = 'Legend';
$_MODULE['<{homeslider}prestashop>homeslider_d0042a700e9bdf79689d63ee6846dc0e'] = 'Description';
$_MODULE['<{homeslider}prestashop>homeslider_3d091e856cb7615d1ccb96bc759b5a92'] = 'Active';
$_MODULE['<{homeslider}prestashop>homeslider_ea4788705e6873b424c65e91c2846b19'] = 'Cancel';
$_MODULE['<{homeslider}prestashop>homeslider_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'The block configuration has been updated.';
$_MODULE['<{homeslider}prestashop>homeslider_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{homeslider}prestashop>homeslider_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{homeslider}prestashop>homeslider_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Active';
$_MODULE['<{homeslider}prestashop>homeslider_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
