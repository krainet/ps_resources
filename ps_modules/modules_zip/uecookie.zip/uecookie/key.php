<?PHP 
$this->mkey="freelicense";
?>