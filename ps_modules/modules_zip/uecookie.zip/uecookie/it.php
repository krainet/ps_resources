<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{uecookie}prestashop>top_716f6b30598ba30945d84485e61c1027'] = 'Ok';
$_MODULE['<{uecookie}prestashop>uecookie_fba6a93b46d375a50cb1c58b84899053'] = 'Questo modulo visualizza una informazione bella di Cookies nel vostro negozio';
$_MODULE['<{uecookie}prestashop>uecookie_1061fda795260b08e769c493105557f7'] = 'Questo negozio utilizza i cookie e altre tecnologie in modo che possiamo migliorare la tua esperienza sui nostri siti.';
$_MODULE['<{uecookie}prestashop>uecookie_d12652129be13b431f0e491afac0d4fe'] = 'Diritto dell\'Unione europea \"Cookie\".';
$_MODULE['<{uecookie}prestashop>uecookie_4d1d06e0e2f0a31f2806796bf0513c1a'] = 'Testo qui';
$_MODULE['<{uecookie}prestashop>uecookie_52f5e0bc3859bc5f5e25130b6c7e8881'] = 'Posizione';
$_MODULE['<{uecookie}prestashop>uecookie_b28354b543375bfa94dabaeda722927f'] = 'Sopra';
$_MODULE['<{uecookie}prestashop>uecookie_71f262d796bed1ab30e8a2d5a8ddee6f'] = 'Sotto';
$_MODULE['<{uecookie}prestashop>uecookie_368d9ac76af05f714092bc808a426bfc'] = 'Colore Sfondo';
$_MODULE['<{uecookie}prestashop>uecookie_ee5488740d9345ae7768b839dd81c608'] = 'Colore Sfumatura';
$_MODULE['<{uecookie}prestashop>uecookie_bad6a5dd8c28e6b14f8e986615e3dc98'] = 'Opacità';
$_MODULE['<{uecookie}prestashop>uecookie_82968569cca21c585a15d46ee3b58253'] = 'per esempio: 0.5';
$_MODULE['<{uecookie}prestashop>uecookie_43781db5c40ecc39fd718685594f0956'] = 'salvare';
