<?php

if (!defined('_PS_VERSION_'))
	exit;
	
class HiFacebookConnect extends Module{

	public $psv;
	public $error = "";
	public $fb_login_page;
	public $fb_on;
	public $fb_app_id;
	public $fb_position_top;
	public $fb_position_custom;
	public $fb_position_right;
	public $fb_position_left;

	public function __construct(){
		$this->name = 'hifacebookconnect';
		$this->tab = 'front_office_features';
		$this->version = '1.0.0';
		$this->author = 'HiPresta';
		$this->need_instance = 0;
		$psv = floatval(substr(_PS_VERSION_,0,3));
		if ($psv == 1.6)
			$this->bootstrap = true;
		
		parent::__construct();
		
		$this->_globalVars();
	 
		$this->displayName = $this->l('Facebook Connect');
		$this->description = $this->l('Allow your customers to sign in with Facebook');
		$this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
	}

	public function install(){
		if (!parent::install()
			|| !$this->registerHook('displayNav')
			|| !$this->registerHook('top')
			|| !$this->registerHook('header')
			|| !$this->registerHook('rightColumn')
			|| !$this->registerHook('leftColumn')
			|| !$this->registerHook('footer')
			|| !$this->registerHook('hiFacebookConnect')
			|| !$this->createFbTable()

			|| !Configuration::updateValue('HI_FB_LOGIN_PAGE', 'no_redirect')
			|| !Configuration::updateValue('HI_FB_ON', false)
			|| !Configuration::updateValue('HI_FB_APP_ID', '')
			|| !Configuration::updateValue('HI_FB_POSITION_TOP', true) 
			|| !Configuration::updateValue('HI_FB_POSITION_RIGHT', false) 
			|| !Configuration::updateValue('HI_FB_POSITION_LEFT', false) 
			|| !Configuration::updateValue('HI_FB_POSITION_CUSTOM', false)
		)
			return false;
		
		return true;
	}

	public function uninstall(){
		if (!parent::uninstall())
			return false;
			$this->dropFbTable();
		return true;
	}

	private function createFbTable (){
		$sql = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'hifacebookusers` (
		   `id`            INT NOT NULL AUTO_INCREMENT,
		   `id_user`       VARCHAR (100) NOT NULL,
		   `id_shop_group` INT (11) NOT NULL,
		   `id_shop`       INT (11) NOT NULL,
		   `first_name`    VARCHAR (100) NOT NULL,
		   `last_name`     VARCHAR (100) NOT NULL,
		   `email`         VARCHAR (100) NOT NULL,
		   `gender`        VARCHAR (100) NOT NULL,
		   `birthday`      DATE NOT NULL,
		   `date_add`      DATE NOT NULL,
		   `date_upd`      DATE NOT NULL,
		   PRIMARY KEY     ( `id` )
		) ENGINE = '._MYSQL_ENGINE_.' DEFAULT CHARSET=UTF8;';
		return Db::getInstance()->Execute(trim($sql));
	}

	private function dropFbTable(){
		return DB::getInstance()->execute("DROP TABLE IF EXISTS "._DB_PREFIX_."hifacebookusers");
	}

	private function _globalVars(){
		$this->psv = (float)Tools::substr(_PS_VERSION_, 0, 3);
		$this->fb_login_page = Configuration::get('HI_FB_LOGIN_PAGE');
		$this->fb_on = (bool)Configuration::get('HI_FB_ON');
		$this->fb_app_id = Configuration::get('HI_FB_APP_ID');
		$this->fb_position_top = (bool)Configuration::get('HI_FB_POSITION_TOP');
		$this->fb_position_right = (bool)Configuration::get('HI_FB_POSITION_RIGHT');
		$this->fb_position_left = (bool)Configuration::get('HI_FB_POSITION_LEFT');
		$this->fb_position_custom = (bool)Configuration::get('HI_FB_POSITION_CUSTOM');
	}
	
	private function isSelectedShopGroup(){
		if (Shop::getContext() == Shop::CONTEXT_GROUP || Shop::getContext() == Shop::CONTEXT_ALL)
			return true;
		else
			return false;
	}

	protected function isTableExists($table)
	{
		$sqlExistsTable = "SELECT * FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE()
			AND TABLE_NAME='" . _DB_PREFIX_ . $table . "'; ";
		$exists = Db::getInstance()->ExecuteS($sqlExistsTable);
		return !empty($exists);
	}

	public function _displayForm(){
		$psv = floatval(substr(_PS_VERSION_,0,3));
		
		$html = $this->error;
		$html .= $this->generateAdminPage();

		if ($psv < 1.6)
			$this->context->controller->addCSS($this->_path.'css/style1.5.css', 'all');

		return $html;
	}

	private function generateAdminPage(){
		$this->context->smarty->assign(array(
			'action' => Tools::safeOutput($_SERVER['REQUEST_URI']),
			'hi_fb_on' => $this->fb_on,
			'hi_fb_app_id' => $this->fb_app_id,
			'hi_fb_position_top' => $this->fb_position_top,
			'hi_fb_position_right' => $this->fb_position_right,
			'hi_fb_position_left' => $this->fb_position_left,
			'hi_fb_position_custom' => $this->fb_position_custom,
			'hi_login_page' => $this->fb_login_page
		));
		return $this->display(__FILE__, 'views/templates/admin/admin'.$this->psv.'.tpl');
	}

	private function _postProcess(){
		Configuration::updateValue('HI_FB_LOGIN_PAGE', Tools::getValue('hi_fb_login_page'));
		Configuration::updateValue('HI_FB_ON', (bool)Tools::getValue('hi_fb_on'));
		Configuration::updateValue('HI_FB_APP_ID', trim(Tools::getValue('hi_fb_app_id')));
		Configuration::updateValue('HI_FB_POSITION_TOP', (bool)Tools::getValue('hi_fb_position_top'));
		Configuration::updateValue('HI_FB_POSITION_RIGHT', (bool)Tools::getValue('hi_fb_position_right'));
		Configuration::updateValue('HI_FB_POSITION_LEFT', (bool)Tools::getValue('hi_fb_position_left'));
		Configuration::updateValue('HI_FB_POSITION_CUSTOM', (bool)Tools::getValue('hi_fb_position_custom'));
	}

	public function getContent(){
		$html = "";
		if (Tools::isSubmit('hi_fb_submit'))
			$this->_postProcess();

		$this->_globalVars();
		
		if (!$this->isSelectedShopGroup()){	
			$html .= $this->_displayForm();
		}else{
			$html .= '
				<p class="alert alert-warning">'.
					$this->l('You cannot manage the module from a "All Shops" or a "Group Shop" context, select directly the shop you want to edit').'
				</p>';
		}	
		return $html;
	}

	public function prepareHooks($hook){
		$fb_enable = false;
		
		// is Facebook active
		if ($this->fb_on && $this->fb_app_id && $this->{'fb_position_'.$hook} && !$this->context->customer->isLogged())
			$fb_enable = true;

		$this->context->smarty->assign(array(
			'hi_fb_on' => $fb_enable,
			'hi_login_page' => $this->fb_login_page
		));
	}

	public function hookDisplayHeader(){
		$fb_enable = false;
		
		if ($this->fb_on && $this->fb_app_id && ($this->fb_position_top || $this->fb_position_custom || $this->fb_position_left || $this->fb_position_right)&& !$this->context->customer->isLogged())
			$fb_enable = true;
		
		$this->context->smarty->assign(array(
			'hi_fb_on' => $fb_enable,
			'hi_fb_app_id' => $this->fb_app_id,
			'hi_fb_login_page' => $this->fb_login_page
		));
		$psv = floatval(substr(_PS_VERSION_,0,3));
		
		return $this->display(__FILE__,'header.tpl').($psv == 1.6 ? $this->context->controller->addCSS(($this->_path).'css/buttonsStyle.css', 'all') : $this->context->controller->addCSS(($this->_path).'css/buttonsStyle1.5.css', 'all'));
	}

	public function hookTop($params){
		$psv = floatval(substr(_PS_VERSION_,0,3));
		if ($psv < 1.6)
			$this->hookDisplayNav($params);
	}

	public function hookDisplayNav($params){
		$this->prepareHooks('top');
		return $this->display(__FILE__, 'hooknav.tpl');	
	}
	
	public function hookLeftColumn($params){
		$this->prepareHooks('left');
		return $this->display(__FILE__, 'sidebar.tpl');
	}
	
	public function hookRightColumn($params){
		$this->prepareHooks('right');
		return $this->display(__FILE__, 'sidebar.tpl');
	}
	
	public function hookHiFacebookConnect($params){
		if ($this->fb_on && $this->fb_app_id && $this->fb_position_custom && !$this->context->customer->isLogged()){
			return $this->display(__FILE__, 'facebookCustomHook.tpl');
		}
	}

	public function sendConfirmationMail(Customer $customer, $password){
		if (!Configuration::get('PS_CUSTOMER_CREATION_EMAIL'))
			return true;
		return Mail::Send(
			$this->context->language->id,
			'account',
			Mail::l('Welcome!'),
			array(
				'{firstname}' => $customer->firstname,
				'{lastname}' => $customer->lastname,
				'{email}' => $customer->email,
				'{passwd}' => $password),
			$customer->email,
			$customer->firstname.' '.$customer->lastname
		);
	}
}