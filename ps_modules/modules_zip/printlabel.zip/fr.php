<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{printlabel}prestashop>printlabel_8e4c2fc644cef0f9be3582f76418136c'] = 'Impression Etiquette';
$_MODULE['<{printlabel}prestashop>printlabel_3c4c1269eb0eacaf38aa1416d48ed15c'] = 'Vous permet d\'éditer vos étiquettes d\'envoi';
$_MODULE['<{printlabel}prestashop>printlabel_a0bd08ab74abe88a2afda5818fd3f347'] = 'Le jeton est requis';
$_MODULE['<{printlabel}prestashop>printlabel_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Confirmation';
$_MODULE['<{printlabel}prestashop>printlabel_c888438d14855d7d96a2724ee9c306bd'] = 'Réglages appliqués';
$_MODULE['<{printlabel}prestashop>printlabel_6357d3551190ec7e79371a8570121d3a'] = 'Il y a';
$_MODULE['<{printlabel}prestashop>printlabel_4ce81305b7edb043d0a7a5c75cab17d0'] = 'Il y a';
$_MODULE['<{printlabel}prestashop>printlabel_07213a0161f52846ab198be103b5ab43'] = 'des erreurs';
$_MODULE['<{printlabel}prestashop>printlabel_cb5e100e5a9a3e7f6d1fd97512215282'] = 'une  erreur';
$_MODULE['<{printlabel}prestashop>printlabel_2ee17950f3d09ca60f6f011fb27a2051'] = 'Ce module vous permet d\'éditer vos étiquettes d\'envoi';
$_MODULE['<{printlabel}prestashop>printlabel_f4f70727dc34561dfde1a3c529b6205c'] = 'Réglages';
$_MODULE['<{printlabel}prestashop>printlabel_459a6f79ad9b13cbcb5f692d2cc7a94d'] = 'Jeton';
$_MODULE['<{printlabel}prestashop>printlabel_b17f3f4dcf653a5776792498a9b44d6a'] = 'Appliquer';
$_MODULE['<{printlabel}prestashop>printlabel_48b9b046d2476e744a8d0e5f3330a415'] = 'Etiquette d\'envoi';
$_MODULE['<{printlabel}prestashop>printlabel_84c9f3676e8e548244bc94aac67f9816'] = 'Créer une étiquette d\'envoi';

?>
