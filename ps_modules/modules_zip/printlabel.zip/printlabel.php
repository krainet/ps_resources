<?php

class PrintLabel extends Module {
	private	$_html = '';
	private $_postErrors = array();
	
	function __construct()
    {
        $this->name = 'printlabel';
        $this->version = 0.1;
		$this->tab = 'AdminOrders';
		$this->page = basename(__FILE__, '.php');

        parent::__construct();
		
        $this->displayName = $this->l('Print Label');
        $this->description = $this->l('Allows you to edit delivery labels');
    }

	function install()
	{
		if (!parent::install() OR !$this->registerHook('adminOrder') OR !Configuration::updateValue('EXPINET_TOKEN', 'mytoken'))
			return false;
	}
	
    function uninstall()
    {
        if (!parent::uninstall() OR !Configuration::deleteByName('EXPINET_TOKEN'))
			return false;
    }
    public function getContent()
	{
		$this->_html = '<h2>'.$this->displayName.'</h2>';
		if (isset($_POST['submitExpinet']))
		{
			if (!$_POST['expinet_token'])
				$this->_postErrors[] = $this->l('Token is requirred.');
			if (!sizeof($this->_postErrors))
			{
				Configuration::updateValue('EXPINET_TOKEN', $_POST['expinet_token']);
				$this->displayConf();
			}
			else
				$this->displayErrors();
		}

		$this->displayExpinetDescription();
		$this->displayFormSettings();
		return $this->_html;
	}

	public function displayConf()
	{
		$this->_html .= '
		<div class="conf confirm">
			<img src="../img/admin/ok.gif" alt="'.$this->l('Confirmation').'" />
			'.$this->l('Settings updated').'
		</div>';
	}

	public function displayErrors()
	{
		$nbErrors = sizeof($this->_postErrors);
		$this->_html .= '
		<div class="alert error">
			<h3>'.($nbErrors > 1 ? $this->l('There are') : $this->l('There is')).' '.$nbErrors.' '.($nbErrors > 1 ? $this->l('errors') : $this->l('error')).'</h3>
			<ol>';
		foreach ($this->_postErrors AS $error)
			$this->_html .= '<li>'.$error.'</li>';
		$this->_html .= '
			</ol>
		</div>';
	}
	
	
	public function displayExpinetDescription()
	{
		$this->_html .= '
		<table border="0"><tr>
		<td style="vertical-align: top;">
		<b>'.$this->l('This module allows you to edit delivery labels').'</b><br />
		'.$this->l('').'<br />
		</td></tr></table><br />';
	}

	public function displayFormSettings()
	{
		$conf = Configuration::get('EXPINET_TOKEN');
		
		$this->_html .= '
		<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
		<fieldset>
			<legend><img src="../img/admin/contact.gif" />'.$this->l('Settings').'</legend>
			<label>'.$this->l('Token').'</label>
			<div class="margin-form">
				<input type="text" name="expinet_token" value="'.$conf.'"/>
			</div>
			<br /><center><input type="submit" name="submitExpinet" value="'.$this->l('Update settings').'" class="button" /></center>
		</fieldset>
		</form>';
	}
	
    function hookAdminOrder($params) {
    	$display = '<br /><fieldset style="width: 400px">
			<legend><img src="../img/t/41.gif" /> '.$this->l('Delivery Label').'</legend>
			<a href="../modules/'.$this->name.'/download-label.php?id_order='.$params["id_order"].'&adminfolder='.urlencode(substr($_SERVER["SCRIPT_NAME"], strlen(__PS_BASE_URI__) - 1, - strlen("index.php"))).'&token='.md5(Configuration::get('EXPINET_TOKEN')).'" target="blank" >'.$this->l(' Create a delivery label').'</a><br />
		</fieldset>';
		return $display;
    }

}

?>