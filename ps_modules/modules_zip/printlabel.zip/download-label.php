<?php
require ('../../tools/fpdf/fpdf.php');
//download-label.php?id_order=

//define('PS_ADMIN_DIR', getcwd());
include('../../config/config.inc.php');

if ($_GET["token"] != md5(Configuration::get('EXPINET_TOKEN')))
	Tools::redirect('../..'.urldecode($_GET["adminfolder"]).'login.php');


if(intval($_GET["id_order"]) > 0) {
	$order = new Order(intval($_GET["id_order"]));
	$customer = new Customer($order->id_customer);
	$ad = new Address(intval($order->id_address_delivery));
	$products = $order->getProducts();
	
		//champs adresse � r�cup�rer � l'int�gration
$entreprise=$ad->company;
$prenom=$ad->lastname;
$nom=$ad->firstname;
$champadresse1=$ad->address1;
$champadresse2=$ad->address2;
$codepostal=$ad->postcode;
$ville=$ad->city;
//$id_lang=$ad->id_lang;
$country=$ad->country;

 //$result = Db::getInstance()->getRow('SELECT `name` FROM `'._DB_PREFIX_.'country_lang` WHERE `id_lang` = '.intval(2).' AND `id_country` = '.intval($id_country).'');
	//$name= $result['name'];
	


$pdf=new FPDF('L', 'mm', array(36,89));
$pdf->AddPage();
$pdf->SetDrawColor(255);
$pdf->SetAutoPageBreak(false); 
$pdf->SetFont('Helvetica','',12);
$pdf->SetMargins(10,0,0);
$pdf->SetXY(10,2);
$pdf ->Write(5,"$entreprise \n$prenom $nom \n$champadresse1 \n$champadresse2  \n$codepostal $ville \n$country");
$pdf->Output();
} else {
	echo "No Order identifier.<br />";
}
?>