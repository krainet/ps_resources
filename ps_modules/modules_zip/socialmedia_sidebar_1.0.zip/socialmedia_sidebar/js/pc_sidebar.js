$(function() {
    $( ".pc-social-icon" ).mouseenter(function() {
        $(this).animate({ width: "62"}, "fast");
    });

    $( ".pc-social-icon" ).mouseleave(function() {
        $(this).animate({ width: "50"}, "fast");
    });

});