# Super Abandoned Cart :

An open source module to manage your abandoned cart on your prestashop store.

  - Flexibility 
  - Powerfull
  - Awesome

Increase your sales easily, creates differents campaings and send automatically emails to customers whose abandoned carts.


# How to use :

- New Item "Super Abandoned Cart" on back office menu
- Click on "+" to create new campaign or click on existing campaing to edit it
- Give a campaing name (Campaign name will be mail object)
- Select how many hours/days after abandoned cart to send email
- Create an awesome (and responsive) mail. Tips : Use services like mailchimp, beefree to generate beautiful email)
- Set up the coupon : Name, code, type (percent/fixe), amount, date valid to
- Don't forget to setup cron task to send automatically campaing. (Cron are set to check every 30 minutes if abandoned carts have to be on one campaing)

## Translation :

You can easily change all wording/text with translation menu on back-office.

### Emails example :

(Don't forget to change all links in the mail)

http://pastie.org/10257451

### Prestashop tested version

1.6.0.14
1.6.X

### Version

1.1.5

### Installation

```sh
Download archive file
On back office > Modules > Add new Module > Upload archive
```

### Todo's

- Stasts
- Compatibility with Prestashop < 1.6.X
- Im sure you have some ideas ?

License
----

GPL 


