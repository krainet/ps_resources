<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{extrainfo}prestashop>extrainfo_bfc328668da4835003808cdff4a09f5f'] = 'Ekstra Ürün Bilgi Sekmesi';
$_MODULE['<{extrainfo}prestashop>extrainfo_51ab1a6afddda78a3479c84c42e7ccb4'] = 'Ürün sayfası sekmelerine ekstra bilgi sekmesi ekler (www.cepparca.com | Kodlayan Caglar)';
$_MODULE['<{extrainfo}prestashop>extratab_bfc328668da4835003808cdff4a09f5f'] = 'EKSTRA BİLGİ';
$_MODULE['<{extrainfo}prestashop>extratabcontents_49ee3087348e8d44e1feda1917443987'] = 'Adı';
$_MODULE['<{extrainfo}prestashop>extratabcontents_a517747c3d12f99244ae598910d979c5'] = 'Yazar & Çizer';
$_MODULE['<{extrainfo}prestashop>extratabcontents_bc67a1507258a758c3a31e66d7ceff8f'] = 'Tedarikçi Referansı';
$_MODULE['<{extrainfo}prestashop>extratabcontents_9609dddf3618cff8f67b7829e6fc575e'] = 'ISBN';
$_MODULE['<{extrainfo}prestashop>extratabcontents_7608203603437f0513ba8203a2d39a4f'] = 'Ürün Kodu';
