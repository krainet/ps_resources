Extra Info Module

This module adds an extra product information tab among the product tabs in the product page.

Data field names are adjusted and modified by a request of book seller and can be change easily by editing extratabContents.tpl

Current modifications are presented below:

Author field : uses product reference info
ISBN field : uses EAN13 info
Item code field : uses UPC info

Compatible with Prestashop version 1.4.x

Contact: admin@eskipusku.com

P.S: Module is free of charge, can be distributed or modified without permission of the coder.