<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cookieslaw}prestashop>cookieslaw_d777e82b3d81a06fb783a4d9c7bac7d6'] = 'We use';
$_MODULE['<{cookieslaw}prestashop>cookieslaw_55e7dd3016ce4ac57b9a0f56af12f7c2'] = 'cookies';
$_MODULE['<{cookieslaw}prestashop>cookieslaw_84e9a58171f90c66aa99ecd60244a25f'] = 'to give you the best experience.';
$_MODULE['<{cookieslaw}prestashop>cookieslaw_6120c8fc4b0c5d0cbec35ca6837302e6'] = 'If you do nothing, we\'ll assume that\'s OK.';
$_MODULE['<{cookieslaw}prestashop>cookieslaw_54852be37bf1310f9633a86e2676768e'] = 'OK, I don\'t mind using cookies';
$_MODULE['<{cookieslaw}prestashop>cookieslaw_8ad4303b83a62fb6ca3b025bad5bc114'] = 'No thanks';
